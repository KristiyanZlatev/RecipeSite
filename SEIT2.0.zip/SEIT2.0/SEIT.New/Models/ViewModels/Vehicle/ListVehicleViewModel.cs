﻿namespace SEIT.New.Models.ViewModels.Vehicle
{
    public class ListVehicleViewModel
    {
        public IEnumerable<VehicleViewModel> VehicleList { get; set; } = new List<VehicleViewModel>();
        public Utility.PageInfo PageInfo { get; set; } = new Utility.PageInfo();

        public string SearchingText { get; set; } = string.Empty;
    }
}
