using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using SEIT.New.CustomMiddleWare;
using SEITNew.Repositories;
using SEITNew.Repositories.Implementation;
using SEITNew.Repositories.Infrastructure;
namespace SEIT.New
{ 
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);
            // configure dbcontext with connectionstring
            // Add services to the container.
            var connectionString = builder.Configuration.GetConnectionString("DefaultConnection") ?? throw new InvalidOperationException("Connection string 'DefaultConnection' not found.");
            builder.Services.AddDbContext<CarContext>(options =>
                options.UseSqlServer(connectionString));
            builder.Services.AddDatabaseDeveloperPageExceptionFilter();

            builder.Services.AddDefaultIdentity<IdentityUser>(options => options.SignIn.RequireConfirmedAccount = true)
                .AddEntityFrameworkStores<CarContext>();
            builder.Services.AddControllersWithViews();

            // Ensure IVehicleRepository and VehicleRepository are defined and accessible
            builder.Services.AddScoped<IVehicleRepositories, VehicleRepositories>();
            builder.Services.AddAutoMapper(typeof(VehicleRepositories));

            var app = builder.Build();

            app.UseMiddleware<ExceptionHandlerMiddleware>();
            // Configure the HTTP request pipeline.
            if (app.Environment.IsDevelopment())
            {
                app.UseMigrationsEndPoint();
            }
            else
            {
                app.UseExceptionHandler("/Home/Error");
                app.UseHsts();
            }

            app.UseHttpsRedirection();
            app.UseStaticFiles();

            app.UseRouting();
            app.UseAuthentication();
            app.UseAuthorization();


            app.MapStaticAssets();
            app.MapControllerRoute(
                name: "default",
                pattern: "{controller=Vehicles}/{action=Index}/{id?}")
                .WithStaticAssets();
            app.MapRazorPages()
               .WithStaticAssets();

            app.Run();
        }
    }
}
