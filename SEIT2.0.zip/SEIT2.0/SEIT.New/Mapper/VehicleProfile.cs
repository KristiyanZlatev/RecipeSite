﻿using AutoMapper;
using SEIT.New.Models.ViewModels.Vehicle;
using SEITNew.Models;

namespace SEIT.New.Mapper
{
    public class VehicleProfile : Profile
    {
        public VehicleProfile()
        {
            CreateMap<Vehicle, VehicleViewModel>();
        }

    }
}
