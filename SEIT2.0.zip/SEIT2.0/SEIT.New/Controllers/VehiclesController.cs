﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Identity.Client;
using SEIT.New.Models.ViewModels.Vehicle;
using SEITNew.Repositories.Infrastructure;

namespace SEIT.New.Controllers
{
    public class VehiclesController : Controller
    {
        private readonly IVehicleRepositories _vehicleRepository;
        private IMapper _mapper;

        public VehiclesController(IVehicleRepositories vehicleRepository, IMapper mapper)
        {
            _vehicleRepository = vehicleRepository ?? throw new ArgumentNullException(nameof(vehicleRepository));
            _mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
        }

        public async Task<IActionResult> Index(int pageNumber = 1, int pageSize = 10, string? SearchingText = null)
        {
            IEnumerable<VehicleViewModel> viewModelList;
            var vehicles = _vehicleRepository.GetAllVehicles().GetAwaiter()
             .GetResult().Skip((pageNumber * pageSize) - pageSize).Take(pageSize);

            viewModelList = _mapper.Map<IEnumerable<VehicleViewModel>>(vehicles);
            if (!string.IsNullOrEmpty(SearchingText))
            {
                viewModelList = viewModelList.Where(v => v.VehicleName.Contains(SearchingText) || v.VehicleType.Contains(SearchingText));
            }

            var vehicleviewModel = new ListVehicleViewModel
            {
                VehicleList = viewModelList,
                PageInfo = new Utility.PageInfo
                {
                    ItemsperPage = pageSize,
                    CurrentPage = pageNumber,
                    TotalItems = _vehicleRepository.GetAllVehicles().GetAwaiter()
                      .GetResult().Count()
                }
            };

            return View();

        }
    }
}
