﻿using Microsoft.EntityFrameworkCore;
using SEITNew.Models;
using SEITNew.Repositories.Infrastructure;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SEITNew.Repositories.Implementation
{
    public class VehicleRepositories : IVehicleRepositories
    {
        private readonly CarContext _context;

        public VehicleRepositories(CarContext context)
        {
            _context = context;
        }

        public async Task DeleteVehicle(int id)
        {
            var vehicle = await _context.Vehicles.FindAsync(id);
            if (vehicle != null)
            {
                _context.Vehicles.Remove(vehicle);
                await _context.SaveChangesAsync();
            }
        }

        public async Task<Vehicle> GetVehicleById(int id)
        {
            var vehicle = await _context.Vehicles.FindAsync(id);
            if (vehicle != null)
            {
                return vehicle;
            }
            throw new Exception($"Vehicle with ID{id} not found");
        }

        public async Task<IEnumerable<Vehicle>> GetAllVehicles()
        {
            var vehicles = await _context.Vehicles.ToListAsync();
            return vehicles;
        }

        public async Task InsertVehicle(Vehicle vehicle)
        {
            await _context.Vehicles.AddAsync(vehicle);
            await _context.SaveChangesAsync();
        }

        public async Task UpdateVehicle(Vehicle vehicle)
        {
            var VehicleFromDb = await _context.Vehicles.FindAsync(vehicle.Id);
            if (VehicleFromDb != null)
            {
                VehicleFromDb.VehicleName = vehicle.VehicleName;
                VehicleFromDb.VehicleType = vehicle.VehicleType;
                VehicleFromDb.VehicleModel = vehicle.VehicleModel;
                VehicleFromDb.VehicleNumber = vehicle.VehicleNumber;
                VehicleFromDb.VehicleColor = vehicle.VehicleColor;
                VehicleFromDb.VehicleSeats = vehicle.VehicleSeats;
                VehicleFromDb.VehicleDescription = vehicle.VehicleDescription;

                if (vehicle.VehicleImage != null)
                {
                    VehicleFromDb.VehicleImage = vehicle.VehicleImage;
                }

                VehicleFromDb.VehiclePrice = vehicle.VehiclePrice;
                VehicleFromDb.UpdatedAt = DateTime.Now;

                await _context.SaveChangesAsync();
            }

        }
    }
}
