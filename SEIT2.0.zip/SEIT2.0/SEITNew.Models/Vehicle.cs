﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SEITNew.Models
{
    public class Vehicle
    {
        public int Id { get; set; }
        public string VehicleName { get; set; } = string.Empty;
        public string VehicleType { get; set; } = string.Empty;
        public string VehicleModel { get; set; } = string.Empty;
        public string VehicleNumber { get; set; } = string.Empty;
        public string VehicleColor { get; set; } = string.Empty;
        public int VehicleSeats { get; set; }
        public string VehicleDescription { get; set; } = string.Empty;
        public string VehicleImage { get; set; } = string.Empty;
        public decimal VehiclePrice { get; set; }
        public bool IsAvailable { get; set; }
        public bool IsDeleted { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime? UpdatedAt { get; set; }

        // Navigation properties
        public virtual ICollection<Rental> Bookings { get; set; } = new List<Rental>();
    }
}

