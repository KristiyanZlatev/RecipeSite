﻿using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SEITNew.Models
{
    public class ApplicationUser: IdentityUser

    {
            public string FirstName { get; set; } = string.Empty;
            public string Address { get; set; } = string.Empty;
            public string EGN { get; set; } = string.Empty;

        // Navigation properties
        public virtual ICollection<Rental> Bookings { get; set; } = new List<Rental>();
        
    }
}

